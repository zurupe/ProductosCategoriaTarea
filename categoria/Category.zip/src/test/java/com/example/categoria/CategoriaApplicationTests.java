package com.example.categoria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
